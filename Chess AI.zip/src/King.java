public class King extends Piece {

    boolean wasMoved = false;
	public King(){}
    public King(int x, int y, Colour culoare) {
        super(x, y, culoare);
    }

    @Override
    public int getValue() {
        return 900;
    }

    @Override
    public String toString() {
        return "King{" +
                "wasMoved=" + wasMoved +
                ", x=" + x +
                ", y=" + y +
                ", canCheck=" + canCheck +
                ", kingIsInCheck=" + kingIsInCheck +
                '}';
    }

    @Override
    public String getType() {
        return "King";
    }

    @Override
    public int isLegalMoveWhite(int x, int y) {

        this.canCheck = false;

        if (isOnTable(x, y)) {

            if(this.getCuloare() == Colour.WHITE)
                    if ((x == this.x - 1 && y == this.y - 1) || (x == this.x + 1 && y == this.y - 1) ||
                            (x == this.x - 1 && y == this.y + 1) || (x == this.x + 1 && y == this.y + 1) ||
                            (x == this.x && y == this.y - 1) || (x == this.x && y == this.y + 1) ||
                            (x == this.x - 1 && y == this.y) || (x == this.x + 1 && y == this.y)) {
                        if (Main.board.board[x][y].getPiece() instanceof Empty) {
                            //wasMoved = true;
//                            System.out.println("Se muta o casuta");
                            return 1;
                        } else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) {
                            if (!(Main.board.board[x][y].getPiece() instanceof King)) {
                                //wasMoved = true;
                                System.out.println("Ia o piesa neagra");
                                return 2;
                            } else if (Main.board.board[x][y].getPiece() instanceof King) {
                                System.out.println("Da sah regelui negru");
                                this.canCheck = true;
                            }
                        }
                    }
                    else if(canLittleCastlingWhite()){     // Aici e posibila roacada
                    	System.out.println("Rocada mica posibila pentru regele alb");
                    	return 3;
                    }
					else if(canBigCastlingWhite()){     // Aici e posibila roacada
						System.out.println("Rocada mare  posibila pentru regele alb");
						return 4;
					}

                }
        return 0;
    }

    public int isLegalMoveWhiteCuParametru(int x, int y, Board board) {

        this.canCheck = false;

        if (isOnTable(x, y)) {

            if(this.getCuloare() == Colour.WHITE)
                if ((x == this.x - 1 && y == this.y - 1) || (x == this.x + 1 && y == this.y - 1) ||
                        (x == this.x - 1 && y == this.y + 1) || (x == this.x + 1 && y == this.y + 1) ||
                        (x == this.x && y == this.y - 1) || (x == this.x && y == this.y + 1) ||
                        (x == this.x - 1 && y == this.y) || (x == this.x + 1 && y == this.y)) {
                    if (board.board[x][y].getPiece() instanceof Empty) {
                        //wasMoved = true;
//                            System.out.println("Se muta o casuta");
                        return 1;
                    } else if (board.board[x][y].getPiece().getCuloare() != this.getCuloare()) {
                        if (!(board.board[x][y].getPiece() instanceof King)) {
                            //wasMoved = true;
                            System.out.println("Ia o piesa neagra");
                            return 2;
                        } else if (board.board[x][y].getPiece() instanceof King) {
                            System.out.println("Da sah regelui negru");
                            this.canCheck = true;
                        }
                    }
                }
                else if(canLittleCastlingWhite()){     // Aici e posibila roacada
                    System.out.println("Rocada mica posibila pentru regele alb");
                    return 3;
                }
                else if(canBigCastlingWhite()){     // Aici e posibila roacada
                    System.out.println("Rocada mare  posibila pentru regele alb");
                    return 4;
                }

        }
        return 0;
    }

    public boolean canLittleCastlingWhite(){

//        if(!movableKingWhite(this.x,this.y+1) && !movableKingWhite(this.x,this.y + 2) &&
//                (Main.board.board[this.x][this.y+1].getPiece() instanceof Empty) && (Main.board.board[this.x][this.y+2].getPiece() instanceof Empty))
//            if(!this.wasMoved && isOnTable(this.x,this.y + 3) && Main.board.board[this.x][this.y+3].getPiece() instanceof Rook)
//            {
//                Rook rook_aux = (Rook) Main.board.board[this.x][this.y+3].getPiece();
//                if(!rook_aux.wasMoved)
//                    return true;
//            }
        return false;
    }

	public boolean canLittleCastlingBlack(){

	    if (isOnTable(this.x,this.y + 1) && isOnTable(this.x,this.y + 2))
		if(!movableKingBlack(this.x,this.y+1) && !movableKingBlack(this.x,this.y + 2) &&
				(Main.board.board[this.x][this.y+1].getPiece() instanceof Empty) && (Main.board.board[this.x][this.y+2].getPiece() instanceof Empty))
			if(!this.wasMoved && isOnTable(this.x,this.y + 3))
                if (Main.board.board[this.x][this.y+3].getPiece() instanceof Rook) {
				        Rook rook_aux = (Rook) Main.board.board[this.x][this.y+3].getPiece();
                        return !rook_aux.wasMoved;
			        }
		return false;
	}

	public boolean canBigCastlingWhite(){

//		if(!movableKingWhite(this.x,this.y-1) && !movableKingWhite(this.x,this.y - 3) &&
//				(Main.board.board[this.x][this.y-1].getPiece() instanceof Empty) && (Main.board.board[this.x][this.y-3].getPiece() instanceof Empty))
//			if(!this.wasMoved && isOnTable(this.x,this.y - 4) && Main.board.board[this.x][this.y - 4].getPiece() instanceof Rook)
//			{
//				Rook rook_aux = (Rook) Main.board.board[this.x][this.y-4].getPiece();
//				if(!rook_aux.wasMoved)
//					return true;
//			}
		return false;
	}

	public boolean canBigCastlingBlack(){
        if (isOnTable(this.x,this.y - 1) && isOnTable(this.x,this.y - 3))
		if(!movableKingBlack(this.x,this.y-1) && !movableKingBlack(this.x,this.y -3) &&
				(Main.board.board[this.x][this.y-1].getPiece() instanceof Empty) && (Main.board.board[this.x][this.y-3].getPiece() instanceof Empty))
			if(!this.wasMoved && isOnTable(this.x,this.y - 4))
			    if (Main.board.board[this.x][this.y-4].getPiece() instanceof Rook) {
				Rook rook_aux = (Rook) Main.board.board[this.x][this.y-4].getPiece();
                    return !rook_aux.wasMoved;
			}
		return false;
	}

    @Override
    public int isLegalMoveBlack(int x, int y) {
        this.canCheck = false;

        if (isOnTable(x, y)) {

            if(this.getCuloare() == Colour.BLACK)
                    if ((x == this.x - 1 && y == this.y - 1) || (x == this.x + 1 && y == this.y - 1) ||
                            (x == this.x - 1 && y == this.y + 1) || (x == this.x + 1 && y == this.y + 1) ||
                            (x == this.x && y == this.y - 1) || (x == this.x && y == this.y + 1) ||
                            (x == this.x - 1 && y == this.y) || (x == this.x + 1 && y == this.y)) {
                        if (Main.board.board[x][y].getPiece() instanceof Empty) {
                            wasMoved = true;
                            return 1;
                        } else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) {
                            if (!(Main.board.board[x][y].getPiece() instanceof King)) {
                                wasMoved = true;
                                return 2;
                            } else if (Main.board.board[x][y].getPiece() instanceof King)
                                this.canCheck = true;
                        }
                    }
                    else if(canLittleCastlingBlack()) {    // Aici e posibila roacada mica
                    	System.out.println("Rocada  mica posibila pentru regele negru");
                    	return 3;
                    }
					else if(canBigCastlingBlack()) {    // Aici e posibila roacada mare
						System.out.println("Rocada mare posibila pentru regele negru");
						return 4;
					}


                }
        return 0;
    }

}
