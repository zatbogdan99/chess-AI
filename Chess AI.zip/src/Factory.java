public class Factory {
    Piece piece;
    String stringPiece;
    public Factory(Piece piece) {
        this.piece = piece;
    }
    public Factory(String stringPiece) {
        this.stringPiece = stringPiece;
    }
    public Piece getPiece(){
        if (this.piece instanceof Pawn)
            return  new Pawn(this.piece.x,this.piece.y,this.piece.getCuloare());
        if (this.piece instanceof Rook)
            return  new Rook(this.piece.x,this.piece.y,this.piece.getCuloare());
        if (this.piece instanceof Horse)
            return  new Horse(this.piece.x,this.piece.y,this.piece.getCuloare());
        if (this.piece instanceof Bishop)
            return  new Bishop(this.piece.x,this.piece.y,this.piece.getCuloare());
        if (this.piece instanceof Queen)
            return  new Queen(this.piece.x,this.piece.y,this.piece.getCuloare());
        if (this.piece instanceof King)
            return  new King(this.piece.x,this.piece.y,this.piece.getCuloare());
        return new Empty(this.piece.x,this.piece.y,this.piece.getCuloare());
    }
    public Piece getPieceByName(int x, int y, Colour colour,String name){
        switch (name) {
            case "Pawn":
                return new Pawn(x, y, colour);
            case "Horse":
                return new Horse(x, y, colour);
            case "Bishop":
                return new Bishop(x, y, colour);
            case "Rook":
                return new Rook(x, y, colour);
            case "Queen":
                return new Queen(x, y, colour);
            case "King":
                return new King(x, y, colour);
            default:
                return new Empty(x, y, colour);
        }
    }
}
