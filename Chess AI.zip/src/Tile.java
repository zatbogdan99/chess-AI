public  class Tile {
    private Piece piece;

    public void setPiece(Piece piece) {
        this.piece = piece;
    }

    public Piece getPiece() {
        return piece;
    }


    public Tile(Piece piece)
    {
        this.piece=piece;
    }

    @Override
    public String toString() {

        return " " + piece + "(" + piece.getX() + ", " +piece.getY() + ")" + piece.getCuloare() + " ";



    }
}