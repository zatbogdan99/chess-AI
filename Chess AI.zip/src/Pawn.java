import java.util.ArrayList;

public class Pawn extends Piece {
	boolean kingIsInCheck = false;
    public Pawn(int x, int y, Colour culoare) {
        super(x, y, culoare);
    }

    @Override
    public int getValue() {
        return 10;
    }

    public Pawn() {

    }

    @Override
    public String toString() {
        return " Pawn ";
    }

    @Override
    public String getType() {
        return "Pawn";
    }

    @Override
    public int isLegalMoveBlack(int x, int y) {
		for(int p=0; p<=7; p++) {

			Main.timerEnPessantBlack[p] = false;
		}

        this.canCheck = false;
        kingIsInCheck = false;

        if (y > 7 || x < 0)
            return 0;


        int x1 = Main.board.board[this.x][this.y].getPiece().getX();
        int y1 = Main.board.board[this.x][this.y].getPiece().getY();

        Board board = new Board();
        board.board = new Tile[8][8];
        for (int i=0;i < 8;i++) {
            for (int j = 0; j < 8; j++) {
                board.board[i][j] = new Tile(new Factory(Main.board.board[i][j].getPiece()).getPiece());
            }
        }

        board.board[x][y].setPiece(board.board[this.x][this.y].getPiece());
        board.board[x1][y1].setPiece(new Empty(x1,y1,Colour.NO_COLOUR));

        ArrayList<SimpleMove> ceva  = new ArrayList<>();
        if (board.kingCheckBlack2(getKing(),board,ceva))
            return 0;

        for (int i=0;i < 8;i++) {
            for (int j = 0; j < 8; j++) {
                board.board[i][j] = new Tile(new Factory(Main.board.board[i][j].getPiece()).getPiece());
            }
        }

        if (x == this.x + 1) {
            if ((this.y - 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                    (Main.board.board[x][y].getPiece() instanceof King))
                this.canCheck = true;
            if ((this.y + 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                    (Main.board.board[x][y].getPiece() instanceof King))
                this.canCheck = true;
        }

        if(x == this.x + 2){
            if(this.x == 1){
                if ((this.y - 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                        (Main.board.board[x][y].getPiece() instanceof King))
                    this.canCheck = true;
                if ((this.y + 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                        (Main.board.board[x][y].getPiece() instanceof King))
                    this.canCheck = true;
                if (this.y == y && Main.board.board[x][y].getPiece() instanceof Empty){
					if(kingCheckBlack())
						kingIsInCheck=true;
					Main.timerEnPessantBlack[y]=true;
                    return 4;
                }
            }
        }

		if(Main.timerEnPessantWhite[y])
			return 5;

        if (x == this.x + 1) {
            if (this.y == y && Main.board.board[x][y].getPiece() instanceof Empty) {
				if(kingCheckBlack())
					kingIsInCheck=true;
				return 1;
			}
            if ((this.y - 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                                            !(Main.board.board[x][y].getPiece() instanceof King)) {
				if(kingCheckBlack())
					kingIsInCheck=true;
				return 2;
			}
            if ((this.y + 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()) &&
                                            !(Main.board.board[x][y].getPiece() instanceof King)) {
				if(kingCheckBlack())
					kingIsInCheck=true;
				return 3;
			}
        }
        return 0;
    }

    public int isLegalMoveWhite(int x, int y) {
		for(int p=0; p<=7; p++) {
			Main.timerEnPessantWhite[p] = false;

		}

        this.canCheck = false;


        if (y > 7 || x < 0)
            return 0;

		if(x == this.x - 2){
			if(this.x == 6){
                if ((this.y - 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()))
                if (Main.board.board[x][y].getPiece() instanceof King)
                    this.canCheck = true;

                if ((this.y + 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare()))
                if (Main.board.board[x][y].getPiece() instanceof King)
                    this.canCheck = true;

				if (this.y == y && Main.board.board[x][y].getPiece() instanceof Empty){
					if(kingCheckBlack())
						kingIsInCheck=true;
					Main.timerEnPessantWhite[y]=true;
					return 4;
				}
			}
		}

		if(Main.timerEnPessantBlack[y])
			return 5;

		if (x == this.x - 1)  {
            if (this.y == y && Main.board.board[x][y].getPiece() instanceof Empty) {
				return 1;
			}

            if ((this.y - 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare())) {
                    if (Main.board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;
                    else
				        return 2;
			}

            if ((this.y + 1 == y) && (Main.board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare())) {
            if (Main.board.board[x][y].getPiece() instanceof King)
                this.canCheck = true;
            else
                return 3;
			}

        }
        return 0;
    }


    public int isLegalMoveWhiteCuParametru(int x, int y,Board board) {
        for(int p=0; p<=7; p++) {
            Main.timerEnPessantWhite[p] = false;

        }

        this.canCheck = false;


        if (y > 7 || x < 0)
            return 0;

        if(x == this.x - 2){
            if(this.x == 6){
                if ((this.y - 1 == y) && (board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && board.board[x][y].getPiece().getCuloare() != this.getCuloare()))
                    if (board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;

                if ((this.y + 1 == y) && (board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && board.board[x][y].getPiece().getCuloare() != this.getCuloare()))
                    if (board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;

                if (this.y == y && board.board[x][y].getPiece() instanceof Empty){
                    if(kingCheckBlack())
                        kingIsInCheck=true;
                    Main.timerEnPessantWhite[y]=true;
                    return 4;
                }
            }
        }

        if (x == this.x - 1)  {
            if (this.y == y && board.board[x][y].getPiece() instanceof Empty) {
                return 1;
            }

            if ((this.y - 1 == y) && (board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && board.board[x][y].getPiece().getCuloare() != this.getCuloare())) {
                if (board.board[x][y].getPiece() instanceof King)
                    this.canCheck = true;
                else
                    return 2;
            }

            if ((this.y + 1 == y) && (board.board[x][y].getPiece().getCuloare() != Colour.NO_COLOUR && board.board[x][y].getPiece().getCuloare() != this.getCuloare())) {
                if (board.board[x][y].getPiece() instanceof King)
                    this.canCheck = true;
                else
                    return 3;
            }

        }
        return 0;
    }

}
