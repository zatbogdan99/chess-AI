import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Hashtable;

public class StartGame{

    public void start() throws IOException {

        Hashtable<String,Integer> dictColoane = new Hashtable<String,Integer>();
        Hashtable<Integer,Integer> dictLinii = new Hashtable<Integer, Integer>();

        dictColoane.put("a",0);dictLinii.put(0,8);
        dictColoane.put("b",1);dictLinii.put(1,7);
        dictColoane.put("c",2);dictLinii.put(2,6);
        dictColoane.put("d",3);dictLinii.put(3,5);
        dictColoane.put("e",4);dictLinii.put(4,4);
        dictColoane.put("f",5);dictLinii.put(5,3);
        dictColoane.put("g",6);dictLinii.put(6,2);
        dictColoane.put("h",7);dictLinii.put(7,1);dictLinii.put(8,0);

        BufferedReader buff = new BufferedReader(new InputStreamReader(System.in));
        int i=0,j=1;
        boolean e_pe_alb = false;
        boolean forceMode = false;
        int Y_curent = 0,x1_int = 0,X_curent = 0,x2_int= 0,X_nou = 0,Y_nou = 0;
        Minimax minimax;
        while (true) {
            String comand = buff.readLine();
            if (comand.startsWith("protover")) {
                System.out.println("feature usermove=1");
                System.out.flush();
                System.out.println("feature sigint=0");
                System.out.flush();
                System.out.println("feature sigterm=0");
                System.out.flush();


            }
           if(comand.startsWith("xboard")) {
               System.out.println("xboard");
               System.out.flush();
           }

           if (comand.startsWith("new")){
               System.out.println("User is white \n Engine is black");
               Main.board.BoardInit(Colour.BLACK,Colour.WHITE);
               e_pe_alb = false;
               forceMode  = false;
           }

           if (comand.contains("white")){
               System.out.println("User is black \n Engine is white");
                if (!forceMode){
               Main.board.BoardInit(Colour.WHITE,Colour.BLACK);
                e_pe_alb = true;
                forceMode = false;
                 }
                else{
                    e_pe_alb = true;
                }
           }

            if (comand.contains("black")){
                System.out.println("User is white \n Engine is black");
                if (!forceMode) {
                    Main.board.BoardInit(Colour.BLACK, Colour.WHITE);
                    e_pe_alb = false;
                    forceMode = false;
                }else{
                    e_pe_alb = false;
                }
            }

            if(comand.startsWith("show"))
            {
                System.out.print(Main.board);
            }

           if(comand.startsWith("usermove")) {
               String[] x = comand.split(" ");

               String y1 = (String) x[1].subSequence(0, 1);
               Y_curent = dictColoane.get(y1);

               String x1 = (String) x[1].subSequence(1, 2);
               x1_int = Integer.parseInt(x1);
               X_curent = dictLinii.get(x1_int);


               String y2 = (String) x[1].subSequence(2, 3);
               Y_nou = dictColoane.get(y2);


               String x2 = (String) x[1].subSequence(3, 4);
               x2_int = Integer.parseInt(x2);
               X_nou = dictLinii.get(x2_int);



               if (!e_pe_alb) {// user-ul e pe alb

                    if(Main.board.board[X_curent][Y_curent].getPiece().isLegalMoveWhite(X_nou,Y_nou)!=0) {
                    	// ACTUALIZARE TABLA DUPA FIECARE MUTARE A USER-ULUI

						//actualizam tabla atunci cand pionul userului ajunge la capat
						if(Main.board.board[X_curent][Y_curent].getPiece() instanceof Pawn) {
							if(X_nou==0){
								Main.board.board[X_curent][Y_curent].setPiece(new Queen(X_curent, Y_curent, Main.board.board[X_curent][Y_curent].getPiece().getCuloare()));
							}

						}
                        //actualizam tabla pentru rocada mica
                        if(Main.board.board[X_curent][Y_curent].getPiece() instanceof King) {
							if (X_curent == X_nou && Y_nou == Y_curent + 2 && ((Y_curent + 3) < 8) && ((Y_curent + 1) < 8)) {
								Main.board.board[X_curent][Y_curent + 3].setPiece(new Empty(X_curent, Y_curent + 3, Colour.NO_COLOUR));
								Main.board.board[X_curent][Y_curent + 1].setPiece(new Rook(X_curent, Y_curent + 1, Main.board.board[X_curent][Y_curent].getPiece().getCuloare()));
							}
							//actualizam tabla pentru rocada mare
							else if (X_curent == X_nou && Y_nou == Y_curent - 2 && (Y_curent - 4 > 0)) {
								Main.board.board[X_curent][Y_curent - 4].setPiece(new Empty(X_curent, Y_curent - 4, Colour.NO_COLOUR));
								Main.board.board[X_curent][Y_curent - 1].setPiece(new Rook(X_curent, Y_curent - 1, Main.board.board[X_curent][Y_curent].getPiece().getCuloare()));
							}
						}
                        //actualizam tabla pentru en passent
                        if(X_curent==3 && ((Y_curent + 1) < 8) && ((Y_curent - 1) > 0)) {
							if (Main.board.board[X_curent][Y_curent - 1].getPiece() instanceof Pawn && Main.timerEnPessantBlack[Y_curent - 1]) {
//								System.out.println("intra pe ifu asta1");
								Main.board.board[X_curent][Y_curent-1].setPiece(new Empty(X_curent , Y_curent-1, Colour.NO_COLOUR));
							} else if (Main.board.board[X_curent][Y_curent + 1].getPiece() instanceof Pawn && Main.timerEnPessantBlack[Y_curent + 1]) {
//								System.out.println("intra pe ifu asta2");
								Main.board.board[X_curent][Y_curent+1].setPiece(new Empty(X_curent , Y_curent+1, Colour.NO_COLOUR));
							}
						}

//                        System.out.println("Am intrat");
                        Main.board.board[X_nou][Y_nou].setPiece(Main.board.board[X_curent][Y_curent].getPiece());
                        Main.board.board[X_curent][Y_curent].setPiece(new Empty(X_curent, Y_curent, Colour.NO_COLOUR));
                        Main.board.board[X_nou][Y_nou].getPiece().setX(X_nou);
                        Main.board.board[X_nou][Y_nou].getPiece().setY(Y_nou);

                    }

                   minimax = new Minimax();
                   SimpleMove move = minimax.nextMove(2,Main.board,true);
                   System.out.println(move);

                    Main.board.board[move.getFromX()][move.getFromY()].getPiece().moveBlack(move.getToX(),move.getToY());
               }
               else{
                   Main.board.board[7 - X_nou][7 - Y_nou].setPiece(Main.board.board[7- X_curent][7 - Y_curent].getPiece());
                   Main.board.board[7 - X_curent][7 - Y_curent].setPiece(new Empty(7 - X_curent, 7 - Y_curent, Colour.NO_COLOUR));
                   Main.board.board[7 - X_nou][7 - Y_nou].getPiece().setX(7 - X_nou);
                   Main.board.board[7 - X_nou][7 - Y_nou].getPiece().setY(7 - Y_nou);

              }


           }

           if(comand.startsWith("force"))
           {
               forceMode=true;
           }

            if(comand.startsWith("go"))
            {
                if (!e_pe_alb) {
                    forceMode = false;
                }
                else
                    if (forceMode){
                    forceMode = false;
                }
                }

            if(comand.startsWith("quit")) {
                break;
            }


         }

    }
}
