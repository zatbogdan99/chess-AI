import java.util.ArrayList;

public class Minimax {

    private int scoreForColour(Tile[][] board, Colour colour){
        int total = 0;
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++){
                if (board[i][j].getPiece().getCuloare() == colour)
                    total += board[i][j].getPiece().getValue();
            }
        return total;
    }

    private int scoreEvaluator(Tile[][] board){
        return scoreForColour(board,Colour.BLACK) - scoreForColour(board, Colour.WHITE);
    }

    public ArrayList<SimpleMove> posibleMoves(Board board,Colour colour){
        ArrayList<SimpleMove> moves = new ArrayList<>();

        int firstBlackX = 0;
        int firstBlackY = 0;
        for (int i=0; i<8; i++)
            for (int j=0; j<8; j++)
                if (board.board[i][j].getPiece().getCuloare() == Colour.BLACK){
                    firstBlackX = i;
                    firstBlackY = j;
                }
        if (!board.board[firstBlackX][firstBlackY].getPiece().kingCheckBlack()) {

            for (int i = 0; i < 8; i++)
                for (int j = 0; j < 8; j++) {
                    if (board.board[i][j].getPiece().getCuloare() == colour)
                        for (int a = 0; a < 8; a++)
                            for (int b = 0; b < 8; b++)
                                if (colour == Colour.BLACK) {
                                    if (board.board[i][j].getPiece().isLegalMoveBlack(a, b) != 0)
                                        moves.add(new SimpleMove(i, j, a, b));
                                } else if (colour == Colour.WHITE) {
                                    if (board.board[i][j].getPiece().isLegalMoveWhite(a, b) != 0)
                                        moves.add(new SimpleMove(i, j, a, b));
                                }
                }
        } else {
            King king = board.board[firstBlackX][firstBlackY].getPiece().getKing();
            for (int i=0; i<8; i++)
                for (int j=0; j<8; j++) {
                    if (king.isLegalMoveBlack(i, j) != 0) {   //Daca se poate muta regele la i j
//                        System.out.println("Se ajunge pana aici islegalmove");
//                        System.out.println("Regele: " + king);
                        // Daca casuta i j e in sah

                        String type = board.board[i][j].getPiece().getType();
                        Colour colorat = board.board[i][j].getPiece().getCuloare();
                        int x1 = board.board[king.x][king.y].getPiece().getX();
                        int y1 = board.board[king.x][king.y].getPiece().getY();
                        int x2 = board.board[i][j].getPiece().getX();
                        int y2 = board.board[i][j].getPiece().getY();

                        Board board2 = new Board();
                        board2.board = new Tile[8][8];
                        for (int k=0;k < 8;k++) {
                            for (int v = 0; v < 8; v++) {
                                board2.board[k][v] = new Tile(new Factory(board.board[k][v].getPiece()).getPiece());
                            }
                        }

                        board2.board[i][j].setPiece(new King(i,j,Colour.BLACK));
                        board2.board[x1][y1].setPiece(new Empty(x1,y1,Colour.NO_COLOUR));
//                        System.out.println("ar trebui sa fie rege pe: " + i + j);
                        King king_aux = new King(i,j,Colour.BLACK);
//                        System.out.println("board_aux:");
//                        System.out.println(board2);

                        ArrayList<SimpleMove> ceva = new ArrayList<>();
                        if (!board2.kingCheckBlack2(king,board2,ceva))
                            moves.add(new SimpleMove(king.x, king.y, i, j));

                        for (int k=0;k < 8;k++) {
                            for (int v = 0; v < 8; v++) {
                                board2.board[k][v] = new Tile(new Factory(board.board[k][v].getPiece()).getPiece());
                            }
                        }
                    }
                }
//            System.out.println("Estem aici");
        }
//        System.out.println(moves);
        return moves;
    }

    public SimpleMove nextMove(int depth,Board oldBoard, boolean isMaximizingPlayer){
        ArrayList<SimpleMove> moves = new ArrayList<>();
        moves = posibleMoves(oldBoard,Colour.BLACK);
        int bestMove = -9999;
        //Daca e sah mat nu conteaza ce mutare e in lista
        SimpleMove bestMoveFound = new SimpleMove(0,0,0,0);
        //Daca e sah mat
        if (moves.size() > 0) {
            bestMoveFound = moves.get(0);
        }

        for (SimpleMove newGameMove : moves){

            ArrayList<SimpleMove> minimax_moves = new ArrayList<>();
            //board = odlBoard
            Board board = new Board();
            board.board = new Tile[8][8];
            for (int i=0;i < 8;i++) {
                for (int j = 0; j < 8; j++) {
                    board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                }
            }

            board.board[newGameMove.getToX()][newGameMove.getToY()].setPiece(board.board[newGameMove.getFromX()][newGameMove.getFromY()].getPiece());
            board.board[newGameMove.getFromX()][newGameMove.getFromY()].setPiece(new Empty(newGameMove.getFromX(),newGameMove.getFromY(),Colour.NO_COLOUR));
            board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().setX(newGameMove.getToX());
            board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().setY(newGameMove.getToY());
            int value = minimax(depth - 1,board, !isMaximizingPlayer,minimax_moves);

            //oldBoard = board
            for (int i=0;i < 8;i++) {
                for (int j = 0; j < 8; j++) {
                    board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                }
            }

            if (value >= bestMove){
                bestMove = value;
                bestMoveFound = newGameMove;
            }
        }
        return bestMoveFound;
    }

    private int minimax(int depth,Board oldBoard, boolean isMaximisingPlayer, ArrayList<SimpleMove> moves){

        if (depth == 0)
            return scoreEvaluator(oldBoard.board);

        if (isMaximisingPlayer) {
            int bestMove = -9999;
            if (moves.size() == 0)
                moves = posibleMoves(oldBoard, Colour.BLACK);
            for (SimpleMove simplemove : moves) {

                //board = oldBoard
                Board board = new Board();
                board.board = new Tile[8][8];
                for (int i=0;i < 8;i++) {
                    for (int j = 0; j < 8; j++) {
                        board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                    }
                }

                board.board[simplemove.getToX()][simplemove.getToY()].setPiece(board.board[simplemove.getFromX()][simplemove.getFromY()].getPiece());
                board.board[simplemove.getFromX()][simplemove.getFromY()].setPiece(new Empty(simplemove.getFromX(),simplemove.getFromY(),Colour.NO_COLOUR));
                board.board[simplemove.getToX()][simplemove.getToY()].getPiece().setX(simplemove.getToX());
                board.board[simplemove.getToX()][simplemove.getToY()].getPiece().setY(simplemove.getToY());
                moves = posibleMoves(board, Colour.BLACK);
                bestMove = Math.max(bestMove, minimax(depth - 1,board, !isMaximisingPlayer,moves));

                //oldBoard = board
                for (int i=0;i < 8;i++) {
                    for (int j = 0; j < 8; j++) {
                        board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                    }
                }


            }
            return bestMove;
        } else {
            int bestMove = 9999;
            if (moves.size() == 0)
                moves = posibleMoves(oldBoard, Colour.WHITE);
            for (SimpleMove simplemove : moves){

                //board = oldBoard
                Board board = new Board();
                board.board = new Tile[8][8];
                for (int i=0;i < 8;i++) {
                    for (int j = 0; j < 8; j++) {
                        board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                    }
                }

                board.board[simplemove.getToX()][simplemove.getToY()].setPiece(board.board[simplemove.getFromX()][simplemove.getFromY()].getPiece());
                board.board[simplemove.getFromX()][simplemove.getFromY()].setPiece(new Empty(simplemove.getFromX(),simplemove.getFromY(),Colour.NO_COLOUR));
                board.board[simplemove.getToX()][simplemove.getToY()].getPiece().setX(simplemove.getToX());
                board.board[simplemove.getToX()][simplemove.getToY()].getPiece().setY(simplemove.getToY());
                moves = posibleMoves(board, Colour.WHITE);
                bestMove = Math.min(bestMove, minimax(depth - 1,board, !isMaximisingPlayer,moves));

                //oldBoard = board
                for (int i=0;i < 8;i++) {
                    for (int j = 0; j < 8; j++) {
                        board.board[i][j] = new Tile(new Factory(oldBoard.board[i][j].getPiece()).getPiece());
                    }
                }

            }
            return bestMove;
        }
    }
}
