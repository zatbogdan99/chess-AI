public class Empty extends Piece {
    public Empty(int x, int y, Colour culoare) {
        super(x, y, culoare);
    }

    @Override
    public int getValue() {
        return 0;
    }

    @Override
    public int isLegalMoveBlack(int x, int y) {
        return 0;
    }

    @Override
    public int isLegalMoveWhite(int x, int y) {
        return 0;
    }


    public String toString() {
        return " Empty ";
    }

    @Override
    public String getType() {
        return "Empty";
    }

    @Override
    public int isLegalMoveWhiteCuParametru(int x, int y, Board board) {
        return 0;
    }
}
