import java.util.ArrayList;

class Pair {
    int toX;
    int toY;
    int fromX;
    int fromY;
    String typeFrom;
    String typeTo;
    Colour colourFrom;
    Colour colourTo;

    public Pair(int toX, int toY, int fromX, int fromY, String typeFrom,
                String typeTo, Colour colourFrom, Colour colourTo) {
        this.toX = toX;
        this.toY = toY;
        this.fromX = fromX;
        this.fromY = fromY;
        this.typeFrom = typeFrom;
        this.typeTo = typeTo;
        this.colourFrom = colourFrom;
        this.colourTo = colourTo;
    }

    public int getToX() {
        return toX;
    }

    public int getToY() {
        return toY;
    }

    public int getFromX() {
        return fromX;
    }

    public int getFromY() {
        return fromY;
    }

    public Colour getColourFrom() {
        return colourFrom;
    }

    public void setColourFrom(Colour colourFrom) {
        this.colourFrom = colourFrom;
    }

    public Colour getColourTo() {
        return colourTo;
    }

    public void setColourTo(Colour colourTo) {
        this.colourTo = colourTo;
    }

    public void setToX(int toX) {
        this.toX = toX;
    }

    public void setToY(int toY) {
        this.toY = toY;
    }

    public String getTypeFrom() {
        return typeFrom;
    }

    public void setTypeFrom(String typeFrom) {
        this.typeFrom = typeFrom;
    }

    public String getTypeTo() {
        return typeTo;
    }

    public void setTypeTo(String typeTo) {
        this.typeTo = typeTo;
    }

    public void setFromX(int fromX) {
        this.fromX = fromX;
    }

    public void setFromY(int fromY) {
        this.fromY = fromY;
    }
}

public class Board {

    Tile[][] board;

    public Board()
    {

    }

    public void BoardInit(Colour engine_colour, Colour user_colour)
    {
        board = new Tile[8][8];
        board[0][0]=new Tile(new Rook(0,0,engine_colour));
        board[0][1]=new Tile(new Horse(0,1,engine_colour));
        board[0][2]=new Tile(new Bishop(0,2,engine_colour));
        board[0][3]=new Tile(new Queen(0,3,engine_colour));
        board[0][4]=new Tile(new King(0,4,engine_colour));
        board[0][5]=new Tile(new Bishop(0,5,engine_colour));
        board[0][6]=new Tile(new Horse(0,6,engine_colour));
        board[0][7]=new Tile(new Rook(0,7,engine_colour));
        for(int i=0;i<=7;i++)
            board[1][i]=new Tile(new Pawn(1,i,engine_colour));

        board[7][0]=new Tile(new Rook(7,0,user_colour));
        board[7][1]=new Tile(new Horse(7,1,user_colour));
        board[7][2]=new Tile(new Bishop(7,2,user_colour));
        board[7][3]=new Tile(new Queen(7,3,user_colour));
        board[7][4]=new Tile(new King(7,4,user_colour));
        board[7][5]=new Tile(new Bishop(7,5,user_colour));
        board[7][6]=new Tile(new Horse(7,6,user_colour));
        board[7][7]=new Tile(new Rook(7,7,user_colour));
        for(int i=0;i<=7;i++)
            board[6][i]=new Tile(new Pawn(6,i,user_colour));

        for(int i=2;i<=5;i++)
            for(int j=0;j<=7;j++)
                board[i][j]=new Tile(new Empty(i,j,Colour.NO_COLOUR));

    }

    public Pair simulateMove(SimpleMove newGameMove){
        Main.board.board[newGameMove.getToX()][newGameMove.getToY()].setPiece(Main.board.board[newGameMove.getFromX()][newGameMove.getFromY()].getPiece());
        Main.board.board[newGameMove.getFromX()][newGameMove.getFromY()].setPiece(new Empty(newGameMove.getFromX(),newGameMove.getFromY(),Colour.NO_COLOUR));
        Main.board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().setX(newGameMove.getToX());
        Main.board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().setY(newGameMove.getToY());

        return new Pair(newGameMove.getToX(),newGameMove.getToY(),newGameMove.getFromX(),newGameMove.getFromY(),
                Main.board.board[newGameMove.getFromX()][newGameMove.getFromY()].getPiece().getType(),
                Main.board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().getType(),
                Main.board.board[newGameMove.getFromX()][newGameMove.getFromY()].getPiece().getCuloare(),
                Main.board.board[newGameMove.getToX()][newGameMove.getToY()].getPiece().getCuloare());
    }

    public void undo(Pair p) {
        Main.board.board[p.getToX()][p.getToY()].setPiece(new Factory(p.typeFrom).getPieceByName(p.toX,p.toY,p.colourTo,p.typeTo));
        Main.board.board[p.getFromX()][p.getFromY()].setPiece(new Factory(p.typeTo).getPieceByName(p.fromX,p.fromY,p.colourFrom,p.typeFrom));
        Main.board.board[p.getToX()][p.getToY()].getPiece().setX(p.fromX);
        Main.board.board[p.getFromX()][p.getFromY()].getPiece().setX(p.toX);
        Main.board.board[p.getToX()][p.getToY()].getPiece().setY(p.fromY);
        Main.board.board[p.getFromX()][p.getFromY()].getPiece().setY(p.toY);
    }

    @Override
    public String toString() {
        String s="";
        for (int i = 0; i <= 7; i++) {
            for (int j = 0; j <= 7; j++)
                s=s+board[i][j];
            s=s+"\n";
        }
        return s;
    }

    public boolean kingCheckBlack2(King king, Board board, ArrayList<SimpleMove> moves) {  // Verifica daca regele botului BLACK e in sah
        int i,j;


                    Board board_aux = new Board();
                    board_aux.board = new Tile[8][8];
                    for (int k = 0; k < 8; k++) {
                        for (int v = 0; v < 8; v++) {
                            board_aux.board[k][v] = new Tile(new Factory(board.board[k][v].getPiece()).getPiece());
                        }
                    }

//                    System.out.println("Coordonate rege:" + king.x + king.y);
                    board_aux.board[king.x][king.y].setPiece(new Empty(king.x, king.y, Colour.NO_COLOUR));

//                    System.out.println(board_aux);

                    for (int a = 0; a < 8; a++)
                        for (int b = 0; b < 8; b++) {
                            if (board_aux.board[a][b].getPiece().getCuloare() == Colour.WHITE) {
                                if (board_aux.board[a][b].getPiece().isLegalMoveWhiteCuParametru(king.x, king.y, board_aux) != 0) {
//                                            System.out.println("e true: " + board_aux.board[a][b].getPiece().isLegalMoveWhiteCuParametru(king.x, king.y, board_aux));
                                            return true;
                                    }
                                }
                            }
                    for (int k = 0; k < 8; k++) {
                        for (int v = 0; v < 8; v++) {
                            board.board[k][v] = new Tile(new Factory(Main.board.board[k][v].getPiece()).getPiece());
                        }
                    }
        return false;
    }
}







