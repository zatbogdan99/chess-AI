import java.util.ArrayList;
import java.util.Hashtable;

enum Colour{WHITE,BLACK,NO_COLOUR;
    }

public abstract class Piece {

    int x;
    int y;
    private Colour culoare;
    boolean canCheck;
    boolean kingIsInCheck;

    public Piece()
    {

    }

    public Piece(int x,int y,Colour culoare) {
        this.x=x;
        this.y=y;
        this.culoare = culoare;
    }

    public void setCuloare(Colour culoare) {
        this.culoare = culoare;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public Colour getCuloare() {
        return this.culoare;
    }

    public abstract int getValue();

    //Metoda move pentru negru
    public boolean moveBlack(int x, int y) {

        if (isLegalMoveBlack(x, y) != 0) {
        	//Rocada mica
        	if(this instanceof King) {
				if (x == this.x && y == this.y + 2 && isOnTable(this.x,this.y + 3) && isOnTable(this.x,this.y + 1)) {
					Main.board.board[this.x][this.y + 3].setPiece(new Empty(this.x, this.y + 3, Colour.NO_COLOUR));
					Main.board.board[this.x][this.y + 1].setPiece(new Rook(this.x, this.y + 1, Main.board.board[this.x][this.y].getPiece().getCuloare()));
				}
				//Rocada mare
				else if (x == this.x && y == this.y -2 && isOnTable(this.x,this.y - 4) && isOnTable(this.x,this.y - 1)) {
					Main.board.board[this.x][this.y -4].setPiece(new Empty(this.x, this.y -4, Colour.NO_COLOUR));
					Main.board.board[this.x][this.y - 1].setPiece(new Rook(this.x, this.y - 1, Main.board.board[this.x][this.y].getPiece().getCuloare()));
				}
			}
			//System.out.println(this.x +" "+ this.y);
			//En Passent
			if(this.x==4 && ((this.y + 1) < 8) && ((this.y - 1) > 0)){
				System.out.println("intra ma");
				System.out.println(this.x +" "+ this.y);
				System.out.println(x +" "+ y);
				System.out.println(Main.board.board[this.x][this.y-1].getPiece().getCuloare());
				if (Main.board.board[this.x][this.y+1].getPiece() instanceof Pawn) {
					System.out.println("emi");
					Main.board.board[x - 1][y].setPiece(new Empty(x - 1, y, Colour.NO_COLOUR));
				} else if (Main.board.board[this.x][this.y-1].getPiece() instanceof Pawn) { // are pion in dreapta
					System.out.println("toni");
					Main.board.board[x-1][y].setPiece(new Empty(x-1, y, Colour.NO_COLOUR));
				}
			}

            System.out.println("move "+ Main.dictColoane.get(this.y)+ Main.dictLinii.get(this.x)+ Main.dictColoane.get(y)+Main.dictLinii.get(x));
            Main.board.board[x][y].setPiece(Main.board.board[this.x][this.y].getPiece());
            Main.board.board[this.x][this.y].setPiece(new Empty(this.x,this.y,Colour.NO_COLOUR));
            Main.board.board[x][y].getPiece().setX(x);
            Main.board.board[x][y].getPiece().setY(y);

			//Transformarea pionului in regina
			if(this instanceof Pawn) {
				if(x==7){
					Main.board.board[x][y].setPiece(new Queen(x, y, Colour.BLACK));
				}

			}
            return true;
        }
        else {
            System.out.println("Illegal movee negru");
            return false;
        }
    }
    //Metoda move, dar pentru alb
    public boolean moveWhite(int x, int y) {
        if (isLegalMoveWhite(x, y) != 0) {

            System.out.println("move "+ Main.dictColoane2.get(this.y)+ Main.dictLinii2.get(this.x)+ Main.dictColoane2.get(y)+Main.dictLinii2.get(x));
            Main.board.board[x][y].setPiece(Main.board.board[this.x][this.y].getPiece());
            Main.board.board[this.x][this.y].setPiece(new Empty(this.x,this.y,Colour.NO_COLOUR));
            Main.board.board[x][y].getPiece().setX(x);
            Main.board.board[x][y].getPiece().setY(y);
            return true;
        }
        else {
            System.out.println("Illegal movee");
            return false;
        }
    }

    public abstract int isLegalMoveBlack(int x, int y);

    public abstract int isLegalMoveWhite(int x, int y);

    public boolean isOnTable(int x, int y){
        return x >= 0 && x <= 7 && y >= 0 && y <= 7;
    }

    @Override
    public String toString() {
        return "Piece{" +
                "x=" + x +
                ", y=" + y +
                ", culoare=" + culoare +
                '}';
    }

    public boolean kingCheckBlack() {  // Verifica daca regele botului BLACK e in sah
        int i,j;
        int kingX=0,kingY=0;
        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(Main.board.board[i][j].getPiece() instanceof King)
                    if(Main.board.board[i][j].getPiece().getCuloare().equals(this.getCuloare()))
                    {
                        kingX = i;
                        kingY = j;
                    }

        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(!(Main.board.board[i][j].getPiece() instanceof Empty))
                    if(Main.board.board[i][j].getPiece().getCuloare() != this.getCuloare()) {
                        Main.board.board[i][j].getPiece().isLegalMoveWhite(kingX, kingY);
                        if(Main.board.board[i][j].getPiece().canCheck) {
                            System.out.println("E in sah regele botului negru!");
                            return true;
                        }

                    }
//        System.out.println("Nu e in sah regele botului negru!");
        return false;
    }

   public King getKing(){
		int i,j;
		int kingX=0,kingY=0;
		King king = new King();
		for(i=0;i<=7;i++)
			for(j=0;j<=7;j++)
				if(Main.board.board[i][j].getPiece() instanceof King)
					if(Main.board.board[i][j].getPiece().getCuloare().equals(this.getCuloare())) {
						kingX = i;
						kingY = j;
					}
		king.setX(kingX);
		king.setY(kingY);
		king.setCuloare(this.getCuloare());

		return king;
	}

   public ArrayList<Piece> saviourBlackPieces(){
		int i,j,a,b;
		ArrayList<Piece> saviourArray= new ArrayList<Piece>();
		if(kingCheckBlack())
		for(i=0;i<=7;i++)
			for(j=0;j<=7;j++)
				if(Main.board.board[i][j].getPiece().getCuloare().equals(this.getCuloare()))
					for(a=0;a<=7;a++)
						for(b=0;b<=7;b++) {
							Main.board.board[i][j].getPiece().isLegalMoveBlack(a, b);
							if(!(Main.board.board[i][j].getPiece().kingIsInCheck))
								saviourArray.add(Main.board.board[i][j].getPiece());
						}
				return saviourArray;

    }


    public boolean kingCheckWhite() { // Verifica daca regele user-ului WHITE e in sah
        int i,j;
        int kingX=0,kingY=0;
        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(Main.board.board[i][j].getPiece() instanceof King)
                    if(Main.board.board[i][j].getPiece().getCuloare().equals(this.getCuloare()))
                    {
                        kingX = i;
                        kingY = j;
                    }

        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(!(Main.board.board[i][j].getPiece() instanceof Empty))
                    if(Main.board.board[i][j].getPiece().getCuloare() != this.getCuloare()) {
                        Main.board.board[i][j].getPiece().isLegalMoveBlack(kingX, kingY);
                        if(Main.board.board[i][j].getPiece().canCheck) {
                            System.out.println("E in sah regele userului alb!");
                            return true;
                        }

                    }
        System.out.println("Nu e in sah regele userului alb!");
        return false;
    }

    public boolean movableKingWhite(int kingX,int kingY) { // Verifica daca o casuta user-ului WHITE e in sah
        int i,j;

        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(!(Main.board.board[i][j].getPiece() instanceof Empty) && !(Main.board.board[i][j].getPiece() instanceof King))
                    if(Main.board.board[i][j].getPiece().getCuloare() != this.getCuloare()) {
                        Main.board.board[i][j].getPiece().isLegalMoveBlack(kingX, kingY);
                        if(Main.board.board[i][j].getPiece().canCheck) {
                            System.out.println("E in sah!");
                            return true;
                        }

                    }
        return false;
    }

    public boolean movableKingBlack2(int kingX,int kingY) { // Verifica daca o casuta  BLACK e in sah
        int i,j;

        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(!(Main.board.board[i][j].getPiece() instanceof King))
                    if(Main.board.board[i][j].getPiece().getCuloare() != this.getCuloare()) {
                        Main.board.board[i][j].getPiece().isLegalMoveWhite(kingX, kingY);
                        if(Main.board.board[i][j].getPiece().canCheck) {
//                            System.out.println("E in sah!");
                            return true;
                        }

                    }
        return false;
    }

    public boolean movableKingBlack(int kingX,int kingY) { // Verifica daca o casuta  BLACK e in sah
        int i,j;

        for(i=0;i<=7;i++)
            for(j=0;j<=7;j++)
                if(!(Main.board.board[i][j].getPiece() instanceof Empty) && !(Main.board.board[i][j].getPiece() instanceof King))
                    if(Main.board.board[i][j].getPiece().getCuloare() != this.getCuloare()) {
                        Main.board.board[i][j].getPiece().isLegalMoveWhite(kingX, kingY);
                        if(Main.board.board[i][j].getPiece().canCheck) {
//                            System.out.println("E in sah!");
                            return true;
                        }

                    }
        return false;
    }

    public abstract String getType();
    public abstract int isLegalMoveWhiteCuParametru(int x,int y, Board board);
}
