import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.Hashtable;

public class Main{
    public static  Board board = new Board();
    public static Boolean[] timerEnPessantBlack = new Boolean[8];
	public static Boolean[] timerEnPessantWhite = new Boolean[8];

    public static Hashtable<Integer,String> dictColoane = new Hashtable<Integer, String>();
    public static Hashtable<Integer,Integer> dictLinii = new Hashtable<Integer, Integer>();

    public static Hashtable<Integer,String> dictColoane2 = new Hashtable<Integer, String>();
    public static Hashtable<Integer,Integer> dictLinii2 = new Hashtable<Integer, Integer>();
    public static void main(String agrs[]) throws IOException {

		for(int p=0; p<=7; p++) {
			Main.timerEnPessantWhite[p] = false;
			Main.timerEnPessantBlack[p] = false;
		}

        dictColoane.put(0,"a");dictLinii.put(0,8);
        dictColoane.put(1,"b");dictLinii.put(1,7);
        dictColoane.put(2,"c");dictLinii.put(2,6);
        dictColoane.put(3,"d");dictLinii.put(3,5);
        dictColoane.put(4,"e");dictLinii.put(4,4);
        dictColoane.put(5,"f");dictLinii.put(5,3);
        dictColoane.put(6,"g");dictLinii.put(6,2);
        dictColoane.put(7,"h");dictLinii.put(7,1);

        dictColoane2.put(0,"h");dictLinii2.put(0,1);
        dictColoane2.put(1,"g");dictLinii2.put(1,2);
        dictColoane2.put(2,"f");dictLinii2.put(2,3);
        dictColoane2.put(3,"e");dictLinii2.put(3,4);
        dictColoane2.put(4,"d");dictLinii2.put(4,5);
        dictColoane2.put(5,"c");dictLinii2.put(5,6);
        dictColoane2.put(6,"b");dictLinii2.put(6,7);
        dictColoane2.put(7,"a");dictLinii2.put(7,8);

        board.BoardInit(Colour.BLACK,Colour.WHITE);
        System.out.print(board);

        StartGame x=new StartGame();
        x.start();

        System.out.println("Noua tabla");

       System.out.print(board);

    }
}
