import java.util.ArrayList;

public class Rook extends Piece {

    boolean wasMoved = false;
    boolean kingIsInCheck = false;


    public Rook(int x, int y, Colour culoare) {
        super(x, y, culoare);
    }

    @Override
    public int getValue() {
        return 50;
    }

    public String toString() {
        return " Rook ";
    }

    @Override
    public String getType() {
        return "Rook";
    }

    @Override
    public int isLegalMoveWhite(int x, int y) {
        int a = Math.abs(this.x - x);
        int b = Math.abs(this.y - y);
        int i = 1;
        boolean drum_liber = true;

        this.canCheck = false;

        if (isOnTable(x, y)) {
            if ((x == this.x  && y == this.y - b)) {
                while (i < b){
                    if (!(Main.board.board[this.x][this.y - i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x  && y == this.y + b) {
                while (i < b){
                    if (!(Main.board.board[this.x][this.y + i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x - a && y == this.y ) {
                while (i < a){
                    if (!(Main.board.board[this.x - i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x + a && y == this.y) {
                while (i < a){
                    if (!(Main.board.board[this.x + i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
        }
        return 0;
    }


    public int isLegalMoveWhiteCuParametru(int x, int y,Board board) {
        int a = Math.abs(this.x - x);
        int b = Math.abs(this.y - y);
        int i = 1;
        boolean drum_liber = true;

        this.canCheck = false;

        if (isOnTable(x, y)) {
            if ((x == this.x  && y == this.y - b)) {
                while (i < b){
                    if (!(board.board[this.x][this.y - i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
                    else if(board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x  && y == this.y + b) {
                while (i < b){
                    if (!(board.board[this.x][this.y + i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
                    else if(board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x - a && y == this.y ) {
                while (i < a){
                    if (!(board.board[this.x - i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
                    else if(board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x + a && y == this.y) {
                while (i < a){
                    if (!(board.board[this.x + i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (board.board[x][y].getPiece() instanceof Empty) {
                        return 1;
                    }
                    else if (board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(board.board[x][y].getPiece() instanceof King)) {
                        return 2;
                    }
                    else if(board.board[x][y].getPiece() instanceof King)
                        this.canCheck = true;
                }
            }
        }
        return 0;
    }

    @Override
    public int isLegalMoveBlack(int x, int y) {
        int a = Math.abs(this.x - x);
        int b = Math.abs(this.y - y);
        int i = 1;
        boolean drum_liber = true;
        this.canCheck = false;

        int x1 = Main.board.board[this.x][this.y].getPiece().getX();
        int y1 = Main.board.board[this.x][this.y].getPiece().getY();

        Board board = new Board();
        board.board = new Tile[8][8];
        for (i=0;i < 8;i++) {
            for (int j = 0; j < 8; j++) {
                board.board[i][j] = new Tile(new Factory(Main.board.board[i][j].getPiece()).getPiece());
            }
        }

        board.board[x][y].setPiece(board.board[this.x][this.y].getPiece());
        board.board[x1][y1].setPiece(new Empty(x1,y1,Colour.NO_COLOUR));

        ArrayList<SimpleMove> ceva  = new ArrayList<>();
        if (board.kingCheckBlack2(getKing(),board,ceva))
            return 0;

        for (i=0;i < 8;i++) {
            for (int j = 0; j < 8; j++) {
                board.board[i][j] = new Tile(new Factory(Main.board.board[i][j].getPiece()).getPiece());
            }
        }

        if (isOnTable(x, y)) {
            if ((x == this.x  && y == this.y - b)) {
                while (i < b){
                    if (!(Main.board.board[this.x][this.y - i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        wasMoved = true;
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        wasMoved = true;
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x  && y == this.y + b) {
                while (i < b){
                    if (!(Main.board.board[this.x][this.y + i].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        wasMoved = true;
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        wasMoved = true;
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x - a && y == this.y ) {
                while (i < a){
                    if (!(Main.board.board[this.x - i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        wasMoved = true;
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        wasMoved = true;
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
            i = 1;
            if (x == this.x + a && y == this.y) {
                while (i < a){
                    if (!(Main.board.board[this.x + i][this.y].getPiece() instanceof Empty)) {
                        drum_liber = false;
                        break;
                    }
                    i++;
                }
                if (drum_liber) {
                    if (Main.board.board[x][y].getPiece() instanceof Empty) {
                        wasMoved = true;
                        return 1;
                    }
                    else if (Main.board.board[x][y].getPiece().getCuloare() != this.getCuloare() && !(Main.board.board[x][y].getPiece() instanceof King)) {
                        wasMoved = true;
                        return 2;
                    }
					else if(Main.board.board[x][y].getPiece() instanceof King)
						this.canCheck = true;
                }
            }
        }
        return 0;
    }


}
